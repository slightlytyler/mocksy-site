'use strict'

import React, { Component, PropTypes } from 'react';
import Radium from 'radium';

@Radium
export default class <% TEMPLATE_TOKEN pascalCase %> extends Component {
  static propTypes = {
  };

  render() {
    return (
      <div>
      </div>
    );
  }
}

const styles = {
};