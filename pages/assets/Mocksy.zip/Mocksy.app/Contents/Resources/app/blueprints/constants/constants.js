'use strict'
// <% TEMPLATE_TOKEN %> need to fix bluprint...

export const actionTypes = {
}